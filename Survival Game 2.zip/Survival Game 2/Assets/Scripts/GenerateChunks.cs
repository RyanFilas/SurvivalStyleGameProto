﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateChunks : MonoBehaviour {

    public GameObject chunk;
    int chunkWidth;
    public int numChunks;
    public int yOffset;
    float seedRight;
    float seedLeft;

    [SerializeField]
    private GameObject generatedTerrain;

    void Start () {
        chunkWidth = chunk.GetComponent<GenerateChunk>().width;
        seedRight = Random.Range(1f, 1000f);
        seedLeft = Random.Range(1f, 1000f);
        Generate();
	}
	
	public void Generate () {
        int lastXright = -chunkWidth;

        for (int i = 0; i < numChunks; i++)
        {
            GameObject newChunk = Instantiate(chunk, new Vector3(lastXright + (chunkWidth), -yOffset), Quaternion.identity) as GameObject;
            newChunk.name = "Chunk";
            newChunk.GetComponent<GenerateChunk>().seed = seedRight;
            newChunk.transform.parent = generatedTerrain.transform;
            lastXright += chunkWidth;
        }

        int lastXleft = -chunkWidth - chunkWidth;
        for (int i = 0; i < numChunks; i++)
        {
            GameObject newChunk = Instantiate(chunk, new Vector3(lastXleft + (chunkWidth), -yOffset), Quaternion.identity) as GameObject;
            newChunk.name = "Chunk";
            newChunk.GetComponent<GenerateChunk>().seed = seedLeft;
            newChunk.transform.parent = generatedTerrain.transform;
            lastXleft -= chunkWidth;
        }
    }
}
