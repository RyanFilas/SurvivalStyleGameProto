﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMovement : MonoBehaviour {

    [SerializeField]
    private float moveSpeed;
    [SerializeField]
    private float moveDamp;

    [SerializeField]
    private float jumpForce;
    [SerializeField]
    private float jumpSpeed;

    [SerializeField]
    private LayerMask groundLayer;
    [SerializeField]
    private LayerMask foregroundLayer;
    private bool isGrounded;
    [SerializeField]
    private float rayDist;

    private BlockInventory blockInv;

    private MapControl mapSys;

    private void Awake()
    {
        blockInv = GameObject.Find("GameManager").GetComponent<BlockInventory>();
        mapSys = GameObject.Find("GameManager").GetComponent<MapControl>();
    }

    void Update () {

        //Get horizontal axis
        float horAxis = Input.GetAxis("Horizontal");

        //If axis active and map isn't open
        if (horAxis != 0 && mapSys.mapOpen == false)
        {
            //Move player using moveSpeed and moveDamp, in world values
            transform.Translate(Vector2.right * ((horAxis * moveSpeed) * (Time.deltaTime * moveDamp)), Space.World);
        }

        //If player presses space and is grounded and map isn't open
        if (Input.GetKeyDown("space") && isGrounded && mapSys.mapOpen == false)
        {
            //Add force to jump
            GetComponent<Rigidbody2D>().AddForce(Vector2.up * (jumpForce * jumpSpeed), ForceMode2D.Impulse);
        }

        //Raycast to check for ground
        if (Physics2D.Raycast(transform.position, Vector2.down, rayDist, groundLayer) || Physics2D.Raycast(transform.position, Vector2.down, rayDist, foregroundLayer))
        {
            isGrounded = true;
        }
        else
        {
            isGrounded = false;
        }
    }

    private void OnCollisionEnter2D(Collision2D col)
    {
        if(col.gameObject.tag == "Pickup")
        {
            //Qty here is how many is given to players inventory
            blockInv.AddToInv(col.gameObject.name, 1);
            Destroy(col.gameObject);
        }
    }
}
