﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileData : MonoBehaviour {

    [Tooltip("Type 0: Dirt\nType 1: Wood\nType 2: Stone\nType 3: Copper\nType 4: Iron\nType 5: Coal\nType 6: Glass")]

    /*
    Type 0: Dirt
    Type 1: Wood
    Type 2: Stone
    Type 3: Copper
    Type 4: Iron
    Type 5: Coal
    */

    public int tileType;

}
