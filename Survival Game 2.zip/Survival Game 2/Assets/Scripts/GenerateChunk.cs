﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateChunk : MonoBehaviour {

    //Reference to BlockSystem Script
    private BlockSystem blockSys;

    public Block terrainGrassSlopeRight;
    public Block terrainGrassSlopeLeft;

    public int width;
    public float heightMultiplier;
    public int heightAddition;

    public float smoothness;

    [HideInInspector]
    public float seed;

    [HideInInspector]
    public int lastH;
    [HideInInspector]
    public int s;
    [HideInInspector]
    public int firstPass = 1;
    [HideInInspector]
    public int h;

    void Start () {

        //Store reference to block system script
        blockSys = GameObject.Find("GameManager").GetComponent<BlockSystem>();

        Generate();

	}
	
	public void Generate () {
		for (int i = 0; i < (width * 2); i++)
        {

            h = Mathf.RoundToInt(Mathf.PerlinNoise(seed, ((i * .5f) + transform.position.x) / smoothness) * heightMultiplier) + heightAddition;

            for (int j = 0; j < h; j++)
            {

                Block selectedTile;

                if (j < h - Random.Range(3f, 9f)) // default -5
                {
                    selectedTile = blockSys.allBlocks[4];
                }
                else if (j < h - 1) //default -1
                {
                    selectedTile = blockSys.allBlocks[3];
                }
                else
                {
                    if (s < h)
                    {
                        //lastH = j;
                        selectedTile = blockSys.allBlocks[2]; //terrainGrassSlopeLeft;
                    }
                    else if (s > h)
                    {
                        //lastH = j;
                        selectedTile = blockSys.allBlocks[1]; //terrainGrassSlopeRight;
                    }
                    else
                    {
                        //lastH = j;
                        selectedTile = blockSys.allBlocks[0];
                    }
                }

                //Create new block object in scene, update name, pos and sprite
                GameObject newTile = new GameObject(selectedTile.blockName);
                newTile.name = selectedTile.blockName;
                newTile.layer = 8;
                newTile.transform.parent = this.gameObject.transform;
                newTile.transform.localPosition = new Vector3((i * .5f), (j * .5f));
                SpriteRenderer newRend = newTile.AddComponent<SpriteRenderer>();
                newRend.sprite = selectedTile.blockSprite;

                //Add box collider, sorting order and layer, split by isSolid
                if (selectedTile.isSolid == true)
                {
                    if(selectedTile == blockSys.allBlocks[1] || selectedTile == blockSys.allBlocks[2])
                    {
                        newTile.AddComponent<PolygonCollider2D>();
                        newTile.layer = 10;
                        newRend.sortingOrder = -10;
                    }
                    else
                    {
                        newTile.AddComponent<BoxCollider2D>();
                        newTile.layer = 10;
                        newRend.sortingOrder = -10;
                    }
                }
                else
                {
                    newTile.AddComponent<BoxCollider2D>();
                    newTile.layer = 11;
                    newRend.sortingOrder = -15;
                }

                if(newTile.name == "Stone")
                {
                    newTile.tag = "TerrainStone";
                }
            }

            s = h;
        }

        ResourceGeneration();
	}

    public void ResourceGeneration()
    {
        foreach(GameObject t in GameObject.FindGameObjectsWithTag("TerrainStone"))
        {
            if(t.transform.parent == this.gameObject.transform)
            {
                float r = Random.Range(0f, 100f);
                Block selectedTile = null;

                if (r < blockSys.allBlocks[7].resourceSpawnChance)
                {
                    selectedTile = blockSys.allBlocks[7];
                }
                else if (r < blockSys.allBlocks[8].resourceSpawnChance)
                {
                    selectedTile = blockSys.allBlocks[8];
                }
                else if (r < blockSys.allBlocks[6].resourceSpawnChance)
                {
                    selectedTile = blockSys.allBlocks[6];
                }

                if (selectedTile != null)
                {
                    //Create new block object in scene, update name, pos and sprite
                    GameObject newResourceTile = new GameObject(selectedTile.blockName);
                    newResourceTile.name = selectedTile.blockName;
                    newResourceTile.layer = 8;
                    newResourceTile.transform.parent = transform;
                    newResourceTile.transform.position = t.transform.position;
                    SpriteRenderer newRend = newResourceTile.AddComponent<SpriteRenderer>();
                    newRend.sprite = selectedTile.blockSprite;
                    Destroy(t);

                    //Add box collider, sorting order and layer, split by isSolid
                    if (selectedTile.isSolid == true)
                    {
                        newResourceTile.AddComponent<BoxCollider2D>();
                        newResourceTile.layer = 10;
                        newRend.sortingOrder = -10;
                    }
                    else
                    {
                        newResourceTile.AddComponent<BoxCollider2D>();
                        newResourceTile.layer = 11;
                        newRend.sortingOrder = -15;
                    }
                }
            }
        }
    }
}
