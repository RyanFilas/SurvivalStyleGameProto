﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildSystem : MonoBehaviour {

    //Reference to BlockSystem Script
    private BlockSystem blockSys;

    //Variables to hold data on current block
    [HideInInspector]
    public int currentBlockID = 0;
    [HideInInspector]
    public Block currentBlock;

    //Value to control scrolling through blocks with mousewheel
    private int selectableBlocksTotal;

    //Variable for the block template
    private GameObject blockTemplate;
    private SpriteRenderer currentRend;

    //Bools to control if building system
    private bool buildModeOn = false;
    private bool buildBlocked = false;

    //Float to adjust the size of blocks when placing in world
    [SerializeField]
    private float blockSizeMod;

    //Layer masks to control raycasting
    [SerializeField]
    private LayerMask foregroundNoBuildLayer;
    [SerializeField]
    private LayerMask backgroundNoBuildLayer;
    [SerializeField]
    private LayerMask allBlocksLayer;

    //Reference to the TerrainContainer placedTerrain & foregroundTerrain/backgroundTerrain
    [SerializeField]
    public GameObject droppedTerrain;
    [SerializeField]
    private GameObject foregroundTerrain;
    [SerializeField]
    private GameObject backgroundTerrain;

    //Reference to the player object
    private GameObject playerObject;

    //Set max build distance from playerObject
    [SerializeField]
    private float maxBuildDistance;

    //Variable to hold reference to inventory
    private BlockInventory blockInv;

    private void Awake()
    {
        //Store reference to block inventory script
        blockInv = GetComponent<BlockInventory>();

        //Store reference to block system script
        blockSys = GetComponent<BlockSystem>();

        //Find player and store reference
        playerObject = GameObject.Find("Player");
    }

    private void Update()
    {
        //If B key pressed, toggle build mode
        if (Input.GetKeyDown("b"))
        {
            //Check inventory to ensure we have blocks to build with
            if(blockInv.CheckInvEmpty() == true && buildModeOn == false)
            {
                return;            
            }

            //Flip bool
            buildModeOn = !buildModeOn;

            //If we have a current template, destroy it
            if(blockTemplate != null)
            {
                Destroy(blockTemplate);
            }

            //If we don't have a current block type set
            if(currentBlock == null)
            {
                //Ensure allBlocks array is ready
                if(blockSys.allBlocks[currentBlockID] != null)
                {
                    //Get a new currentBlock using the ID variable
                    currentBlock = blockSys.allBlocks[currentBlockID];
                }
            }

            if (buildModeOn)
            {
                //Toggle UI to be visible
                blockInv.ToggleInv(true);
                //Create a new object for blockTemplate
                blockTemplate = new GameObject("CurrentBlockTemplate");
                //Add and store reference to a SpriteRenderer on the template object
                currentRend = blockTemplate.AddComponent<SpriteRenderer>();
                //Set the sprite of the template object to match the current block type
                currentRend.sprite = currentBlock.blockSprite;
            }
            else
            {
                //Toggle UI to be hidden
                blockInv.ToggleInv(false);
            }
        }

        //If building and we have a blockTemplate
        if (buildModeOn && blockTemplate != null)
        {
            //Calculate template position using rounding
            float newPosX = Mathf.Round(Camera.main.ScreenToWorldPoint(Input.mousePosition).x / blockSizeMod) * blockSizeMod;
            float newPosY = Mathf.Round(Camera.main.ScreenToWorldPoint(Input.mousePosition).y / blockSizeMod) * blockSizeMod;
            blockTemplate.transform.position = new Vector2(newPosX, newPosY);

            //Create a RaycastHit2D object
            RaycastHit2D rayHit;

            //Determine if foreground or background block is being hit
            if(currentBlock.isSolid == true)
            {
                rayHit = Physics2D.Raycast(blockTemplate.transform.position, Vector2.zero, Mathf.Infinity, foregroundNoBuildLayer);
            }
            else
            {
                rayHit = Physics2D.Raycast(blockTemplate.transform.position, Vector2.zero, Mathf.Infinity, backgroundNoBuildLayer);
            }


            //Set buildBlocked if cursor is over another collider
            if(rayHit.collider != null)
            {
                buildBlocked = true;
            }
            else
            {
                buildBlocked = false;
            }


            //Set buildBlocked if mouse cursor is further away then maxBuildDistance
            if(Vector2.Distance(playerObject.transform.position, blockTemplate.transform.position) > maxBuildDistance)
            {
                buildBlocked = true;
            }

            //Change color of sprite if colliding with another object
            if(buildBlocked)
            {
                currentRend.color = new Color(1f, 0f, 0f, 1f);
            }
            else
            {
                currentRend.color = new Color(1f, 1f, 1f, 1f);
            }

            //Scroll through placeable block tiles
            float mouseWheel = Input.GetAxis("Mouse ScrollWheel");

            //If mousewheel used
            if (mouseWheel != 0)
            {
                if(blockInv.CheckInvEmpty() == false)
                {
                    int newID = -1;

                    while(newID == -1)
                    {
                        newID = blockInv.SelectHeldBlock(mouseWheel);
                    }

                    currentBlockID = newID;

                    //Update current block and template sprite using currentBlockID
                    currentBlock = blockSys.allBlocks[currentBlockID];
                    currentRend.sprite = currentBlock.blockSprite;

                    //Update GUI
                    blockInv.UpdateGUI();
                }
            }

            //Place blocks during build mode active & building is not blocked
            if (Input.GetMouseButtonDown(0) && buildBlocked == false)
            {
                if(blockSys.allBlocks[currentBlockID].amtInInv <= 0)
                {
                    return;
                }

                //Create new block object in scene, update name, pos and sprite
                GameObject newBlock = new GameObject(currentBlock.blockName);
                newBlock.transform.position = blockTemplate.transform.position;
                SpriteRenderer newRend = newBlock.AddComponent<SpriteRenderer>();
                newRend.sprite = currentBlock.blockSprite;

                //Add box collider, sorting order and layer, split by isSolid
                if(currentBlock.isSolid == true)
                {
                    newBlock.AddComponent<BoxCollider2D>();
                    newBlock.layer = 10;
                    newRend.sortingOrder = -10;
                    newRend.transform.parent = foregroundTerrain.transform;
                }
                else
                {
                    newBlock.AddComponent<BoxCollider2D>();
                    newBlock.layer = 11;
                    newRend.sortingOrder = -15;
                    newRend.transform.parent = backgroundTerrain.transform;
                }

                blockSys.allBlocks[currentBlockID].amtInInv--;
                blockInv.UpdateGUI();
            }

            //Destroy blocks during build mode active
            if (Input.GetMouseButtonDown(1) && blockTemplate != null)
            {
                //Raycast to check only for blocks
                RaycastHit2D destroyHit = Physics2D.Raycast(blockTemplate.transform.position, Vector2.zero, Mathf.Infinity, allBlocksLayer);

                //Destroy any object hit within build range
                if (destroyHit.collider != null && Vector2.Distance(playerObject.transform.position, blockTemplate.transform.position) <= maxBuildDistance)
                {
                    if(destroyHit.collider.gameObject.name == "Grass")
                    {
                        GameObject newPickup = new GameObject(blockSys.allBlocks[3].blockName, typeof(SpriteRenderer));
                        newPickup.transform.localScale = new Vector3(0.8f, 0.8f, 1);
                        newPickup.GetComponent<SpriteRenderer>().sprite = blockSys.allBlocks[0].blockSprite;
                        newPickup.AddComponent<BoxCollider2D>();
                        newPickup.AddComponent<Rigidbody2D>();
                        newPickup.tag = "Pickup";
                        newPickup.transform.position = destroyHit.collider.transform.position;
                        newPickup.transform.parent = droppedTerrain.transform;
                        Destroy(destroyHit.collider.gameObject);
                    }
                    else
                    {
                        GameObject newPickup = new GameObject(destroyHit.collider.gameObject.name, typeof(SpriteRenderer));
                        newPickup.transform.localScale = new Vector3(0.8f, 0.8f, 1);
                        newPickup.GetComponent<SpriteRenderer>().sprite = destroyHit.collider.gameObject.GetComponent<SpriteRenderer>().sprite;
                        newPickup.AddComponent<BoxCollider2D>();
                        newPickup.AddComponent<Rigidbody2D>();
                        newPickup.tag = "Pickup";
                        newPickup.transform.position = destroyHit.collider.transform.position;
                        newPickup.transform.parent = droppedTerrain.transform;
                        Destroy(destroyHit.collider.gameObject);
                    }
                }
            }
        }
    }
}
