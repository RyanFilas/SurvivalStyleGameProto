﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapControl : MonoBehaviour {

    [SerializeField]
    private GameObject mainCam;
    [SerializeField]
    private GameObject mapCam;

    public bool mapOpen = false;

    private void Update()
    {
        if (Input.GetKeyDown("m"))
        {
            mapOpen = !mapOpen;

            if (mapOpen)
            {
                mainCam.SetActive(false);
                mapCam.SetActive(true);
            }
            else
            {
                mapCam.SetActive(false);
                mainCam.SetActive(true);
            }
        }
    }
}
